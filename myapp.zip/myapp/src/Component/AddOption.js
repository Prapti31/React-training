/*import { Component } from "react";

export default class AddOption extends Component{
    addUser=(e)=>{
        e.preventDefault()
        const data=e.target.elements.uname.value
        this.props.addusr(data)
    }
    addDept=(e)=>{
        e.preventDefault()
        const deptdata=e.target.elements.deptname.value
        
        this.props.adddpt(deptdata)
    }
    render(){
        return(
            <div>
                <div>
                    
                    <form onSubmit={this.addUser}>
                 <input type="text" name='uname'/>
                    <button>Submit</button>
                    </form>
                    <div id='show'></div>
                </div> 
                <div>
                    
                <form onSubmit={this.addDept}>
             <input type="text" name='deptname'/>
                <button>Submit</button>
                </form>
                <div id='show'></div>
            </div> 
            </div>   

            
        )
    }
}*/

//function


function AddOption(props){
    const addUser=(e)=>{
        e.preventDefault()
        const data=e.target.elements.uname.value
        props.addusr(data)
    }
    const addDept=(e)=>{
        e.preventDefault()
        const deptdata=e.target.elements.deptname.value
        
        props.adddpt(deptdata)
    }
    return(
        <div>
            <div>
                
                <form onSubmit={addUser}>
             <input type="text" name='uname'/>
                <button>Submit</button>
                </form>
                <div id='show'></div>
            </div> 
            <div>
                
            <form onSubmit={addDept}>
         <input type="text" name='deptname'/>
            <button>Submit</button>
            </form>
            <div id='show'></div>
        </div> 
        </div>   

        
    )

}
export default AddOption

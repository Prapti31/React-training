import { Component } from "react";

export default class Counter extends Component{
    state={
        count:10
    }
    add=()=>{
        this.setState((prevState)=>{
            return{
             count:prevState.count+1
            }
        })
        
    }
    Sub=()=>{
        this.setState((prevState)=>{
            return{
                count:prevState.count-1
            }
        })
        
    }
    reset=()=>{
        this.setState((prevstate)=>{
            return{
                count:0
            }
        })
    }
    render(){
        return(
            <div>
                <p>the current count is:{this.state.count}</p>

                <button onClick={this.add}>Add</button>
                <button onClick={this.Sub}>Sub</button>
                <button onClick={this.reset}>Reset</button>
            </div>
        )

        
    }
}
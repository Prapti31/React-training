import { Component } from "react";
const {default:Header}=require("./Header");
const {default:Footer}=require("./Footer");
const {default:Action}=require("./Action");
const {default:AddOption}=require("./AddOption");
const {default:Options}=require("./Options");
const {default:Counter}=require("./Counter");
//import Header from './Header'

export default class MainApp extends Component{
    state={
     userdata:['admin'],
    departments:[]
    }
    emptyUserArray=()=>{
        this.setState(()=>{
            return{

                userdata:[]
            }
        })
    }
    emptyDeptArray=()=>{
        this.setState(()=>{
            return{
                departments:[]
            }
        })
    }
    addUser=(data)=>{
        this.setState((prevState)=>{
            return{
                userdata:prevState.userdata.concat(data)
            }
        })
    }
    addDept=(deptdata)=>{
        this.setState((prevState)=>{
            return{
                departments:prevState.departments.concat(deptdata)
            }
        })
    }
    deleteUser=(data)=>{
        this.setState((prevState)=>{
            return{
            userdata:prevState.userdata.filter((input) => data!==input)
            }
        })
    }
    render(){
        
        
        return(
            <div>
                <h3>
                    <Header hmessage="Welcome to header"/>
                    Welcome to MainApp
                    <AddOption addusr={this.addUser} adddpt={this.addDept}/>
                    <Options udata={this.state.userdata} deptdata={this.state.departments} eu={this.emptyUserArray} ed={this.emptyDeptArray} du={this.deleteUser}/>
                    <Action isData={this.state.userdata.length>0} deptdatas={this.state.departments.length>0}/>
                    
                    <Counter message="here"/>
                    <Footer message="Welcome to Footer"/>
                </h3>
            </div>
        )
    }

}
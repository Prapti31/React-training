import { Component } from "react";

export default class Footer extends Component{
    state={
        filter:'',
        data:[
            {country:'india',capital:'Delhi',population:1000000},
            {
                country:'japan',capital:'tokoyo',population:100000000
            },
            {country:'new zealand',capital:'wellington',population:30000000},
        ]
    }
    searchData(e){
        this.setState({
            filter:e.target.value
        })
    }
    render(){
        let {filter,data}=this.state
        let dataSearch=data.filter(item =>{
            return Object.keys(item).some(key =>
                item[key].toString().toLowerCase().includes(filter.toLowerCase())
            )
        })
        return(
            <div>
                <h3>
                    Search App
                </h3>
                <input type='text' value={filter} placeholder='enter data to search' onChange={this.searchData.bind(this)}/>
                <input type='number' value={filter} placeholder='0' onChange={this.searchData.bind(this)}/>
                <table>
                    <tr>
                        <th>Country</th>
                        <th>Capital</th>
                        <th>Population</th>
                    </tr>
                    {
                        (dataSearch.map(item =>
                            <tr>
                                <td>{item.country}</td>
                                <td>{item.capital}</td>
                                <td>{item.population}</td>
                            </tr>
                            ))
                    }
                </table>
                <hr/>
            </div>
        )
    }
}
import { Component } from "react";

export default class Action extends Component{
    render(){
        return(
            <div>
                <h3>
                    <button disabled={!this.props.isData}>showAction</button>
                    <button disabled={!this.props.deptdatas}>showActionDept</button>
                </h3>
            </div>
        )
    }
}
//import { Component } from "react";
const {default:Option}=require("./Option");

/*export default class Options extends Component{
    render(){
        return(
            <div>
                <div>
                    <p>User data</p>
                    {
                        this.props.udata.map((data)=><Option mydata={data} deldata={this.props.du}/>)
                    }
                  <button onClick={this.props.eu}>Delete Users</button>

                </div>
                <div>

                    <p>Departments Data</p>

                    
                    
                    {
                        this.props.deptdata.map((data)=><Option deptdata={data}/>)
                    }
                    <button onClick={this.props.ed}>Delete Departments</button>
            </div>
            </div>
        )
    }
}*/
function Options(props){
    return(
        <>
            <div>
                <p>User data</p>
                {
                    props.udata.map((data)=><Option mydata={data} deldata={props.du}/>)
                }
              <button onClick={props.eu}>Delete Users</button>

            </div>
            <div>

                <p>Departments Data</p>

                {
                    props.deptdata.map((data)=><Option deptdata={data}/>)
                }
                <button onClick={props.ed}>Delete Departments</button>
        </div>
        </>
    )
}

export default Options
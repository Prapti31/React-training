import { NavLink} from "react-router-dom"
import Portfolio from "./Portfolio";
import UserDetails from "./UserDetails";
import Login from "./Login";
import Register from "./Register";
import NotFound from "./404";

function Header(){
    return(
        // <header>
            
        //     <NavLink to="/" exact={true}></NavLink>
        //     <NavLink to="/Register">Register</NavLink>
        //     <NavLink to="/Portfolio">Portfolio</NavLink>
        //     <NavLink to="/details">UserDetails</NavLink>
        // </header>
        <>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">Login</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="/Register">Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/Portfolio">Portfolio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/UserDetails">UserDetails</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          
        </li>
        <li class="nav-item">
          <a class="nav-link disabled">Disabled</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"></input>
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
</>
    )
}

/*const Header1=()=>{
    return(
        <header>
            <NavLink to="/" exact={true}></NavLink>
            <NavLink to="/Register">Register</NavLink>
            <NavLink to="/Portfolio">Portfolio</NavLink>
        </header>
    )
}*/
export default Header;
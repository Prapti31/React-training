


function NotFound(){
    return(
        <div>
            OOPS...Page not found
        </div>
    )
}
export default NotFound
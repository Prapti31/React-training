import { BrowserRouter,NavLink,Route,Switch} from "react-router-dom"
import Portfolio from "./Portfolio";
import UserDetails from "./UserDetails";
import Login from "./Login";
import Register from "./Register";
import NotFound from "./404";
import Header from "./Header";
import CompRoutes from "./CompRoutes";


function Landingpage(){
    return(
        <div>Landing Page...
            <hr/>
            
            <CompRoutes/>
        </div>
        

    )
}
export default Landingpage

/*const Header=()=>{
    return(
        <header>
            <NavLink to="/" exact={true}></NavLink>
            <NavLink to="/Register">Register</NavLink>
            <NavLink to="/Portfolio">Portfolio</NavLink>
        </header>
    )
}

const routes=(
    <BrowserRouter>
    <Header/>
    <Switch>
        <Route path='/' component={Login} exact={true}/>
        <Route path='/Register' component={Register}/>
        <Route path='/Portfolio' component={Portfolio}/>
        <Route path='/UserDetails' component={UserDetails}/>
        <Route component={NotFound}/>
       </Switch>

    </BrowserRouter>
)*/
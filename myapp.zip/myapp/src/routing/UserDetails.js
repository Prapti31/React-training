

function UserDetails(){
    return(
        <div>Userdetails</div>
    )
}
export default UserDetails
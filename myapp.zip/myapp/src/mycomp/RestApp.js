import { Component } from "react";
import axios from "axios";

const API_URL="http://localhost:5000/api/customer";

export default class RestApp extends Component{

    state={
        users:[]
    }

    componentDidMount(){
        axios.get(API_URL).then(res => res.data) 
    .then((data)=>{ 
        this.setState({users:data})   
        console.log("loading initially");
        
    }) 
    }
    componentDidUpdate(){
        console.log("state is updated");
    }
    render(){
        return <div className='container'>
            <div className='col-xs-8'>
                <h1>User Data</h1>
                {this.state.users.map((user)=>(
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title">{user.firstname}</h5>
                            <h5 className="card-title">{user.email}</h5>
                        </div>
                    </div>
                ))}
            </div>

        </div>;
    }
}
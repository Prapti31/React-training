//const {default:MainApp}=require("./Component/MainApp");
//const {default:RestApp}=require("./mycomp/RestApp");
//import Hooksdemo from "./Hooksdemo/App1";
//import NotesApp from "./Hooksdemo/NotesApp";
//import MainApp1 from "./tasks/MainApp1";
//import ContextApp from "./ContextApp/ContextApp";

import { useSelector,useDispatch } from "react-redux";
import {increment,decrement,reset} from "./reactredux/actions/useractions"
import {login,logout} from "./reactredux/actions/useractions"

//import Landingpage from "./routing/Landingpage";
function App(){
  const counter=useSelector((state)=>state.cntr)
  const dispatch=useDispatch()
  const auth=useSelector((state)=>state.auth)
  return(
    <div>
      <p>The current count is {counter}</p>
      <button onClick={()=> dispatch(increment())}>inc</button>
      <button onClick={()=> dispatch(decrement())}>dec</button>
      <button onClick={()=>dispatch(reset())}>reset</button>
      <br/>
      <div>
        <h2>For Auth User Only</h2>
        <button onClick={()=>dispatch(login())}>Login</button>
        <button onClick={()=>dispatch(logout())}>LogOut</button>
        {
          auth ?(
            <div>
              <p> welcome to application as you have logged in</p>
              </div>
          ) :(
            "Not a valid user"
          )
        }
      </div>
    </div>
  )
}

export default App;

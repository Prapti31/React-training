import { useState,createContext,useContext } from "react"


const empContext=createContext()
function ContextApp(){

    const [employee,setEmployee]= useState({id:101,name:'admin',location:'banglore',salary:12345})
    return(
        <div>
            <empContext.Provider value={employee}>
            <Employee/>
            </empContext.Provider>
        </div>
    )
}
function Employee(){
    let context=useContext(empContext)
    return(
        <div>
            Welcome to Employee
            <br/>
            Name:{context.name}
            <br/>
            location:{context.location}
            <Salary/>
        </div>
    )
}
function Salary(){
    let context=useContext(empContext)
    return(
        <div>
            Welcome to Salary
            <br/>
            Name:{context.name}
            <br/>
            Salary:{context.salary}
        </div>
    )
}
export default ContextApp
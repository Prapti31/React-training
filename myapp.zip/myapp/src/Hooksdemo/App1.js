const { useState }=require("react");

function Hooksdemo(props){
    const [count,setCount]=useState(props.count)

    
    // const decrement=()=>{
    //     setCount(count-1)
    // }
    // const reset=()=>{
    //     setCount(0)
    // }
    return(
        <div>
            <p>the current state is {count}</p>
            <button onClick={()=>setCount(count+1)}>INC</button>
            <button onClick={()=>setCount(count-1)}>Dec</button>
            <button onClick={()=>setCount(0)}>Reset</button>
        </div>

    )
}
Hooksdemo.defaultProps={
    count:0
}

export default Hooksdemo